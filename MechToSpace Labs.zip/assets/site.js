/* MechToSpace site data + shared layout.
   To add a lab or a new version, edit LABS below. Nothing else changes. */
const CFG = {
  // Preview: simulators sit in ./sims/<id>.html
  // Hostinger: set simBase to "https://lab.mechtospace.com/" and simStyle to "folder" (-> /<id>/)
  simBase: "sims/", simStyle: "file",
  clipBase: "clips/"
};
const simURL = (l, v) => CFG.simStyle === "folder"
  ? CFG.simBase + l.id + "/" + (v ? "v" + v + "/" : "")
  : CFG.simBase + l.id + ".html";

const LABS = [
 {id:"porkchop", n:"01", title:"Porkchop Mission Planner", area:"Space · Orbits",
  blurb:"Pick two planets, see every launch date at once, and find the cheapest window to fly.",
  origin:"Carleton orbitals & space control course (MATLAB project)", team:"Solo rebuild",
  uses:["Plans launch windows for satellites and planetary missions","Mission-analysis tools and training for private space","Astrodynamics: AI speeds studies, engineers check orbits"],
  tags:["Lambert solver","Porkchop plot","3D transfer"],
  versions:[{v:"1.0",date:"Nov 2026",notes:"First public build: planet picker, porkchop plot, 3D transfer view, assumed launch site."}]},
 {id:"pcm-fridge", n:"02", title:"PCM Cold-Box Lab", area:"Thermal · Mechanical",
  blurb:"A fridge that keeps cold through power cuts using phase-change material. Change the box, watch the hours.",
  origin:"SRM B.Tech final-year project (team of 4)", team:"Solo rebuild of team project",
  uses:["Vaccine, milk and fish cold boxes that survive power cuts","Cold-box sizing tool and student lab kits","Thermal, HVAC and EV battery cooling"],
  tags:["Heat transfer","COP","Phase change"],
  versions:[{v:"1.0",date:"Nov 2026",notes:"First public build: 3D box, PCM melt model, COP and hold-time charts."}]},
 {id:"solar-drone", n:"03", title:"Solar Cleaning Drone", area:"Drones · Design",
  blurb:"Size a drone that cleans dusty solar panels: payload, battery, flight time and route.",
  origin:"Drone conceptual design per mission (Carleton UAV + internship)", team:"Solo",
  uses:["Cleans solar panels without wasting water or labour","Cleaning-as-a-service for rooftops and farms","Drone systems, AI vision, field robotics"],
  tags:["Sizing","Battery","Mission view"],
  versions:[{v:"1.0",date:"Nov 2026",notes:"First public build: sizing model, 3D mission view."}]},
 {id:"gnc", n:"04", title:"GNC Mission Lab", area:"Drones · Control",
  blurb:"Fly civil drone missions with PID control, guidance laws and a Kalman filter. Break it, then fix it.",
  origin:"Drone internship: waypoint GNC + Kalman filter", team:"Solo",
  uses:["Delivery, crop spraying, inspection and rescue drones","Autonomy software and testing for drone startups","GNC roles in drones, eVTOL and space"],
  tags:["PID","Pure pursuit","Kalman","Monte Carlo"],
  versions:[{v:"1.1",date:"5 Nov 2026",notes:"Civil-only careers section; removed outside job links and company names."},
            {v:"1.0",date:"Nov 2026",retired:true,notes:"First public build: 6 missions, 3 guidance laws, GPS cut, 100-run Monte Carlo."}]},
 {id:"slam", n:"05", title:"SLAM Lab", area:"Robotics · Mapping",
  blurb:"A robot explores an unknown building, builds the map and finds its way, like ROS GMapping.",
  origin:"SLAM study + GMapping implementation", team:"Solo",
  uses:["Warehouse robots, robot vacuums, indoor drones","Mapping and navigation where GPS fails","ROS 2 robotics and localisation"],
  tags:["Particle filter","Occupancy grid","A*","Frontiers"],
  versions:[{v:"1.0",date:"Nov 2026",notes:"First public build: log-odds map, particle filter, frontier exploration, A*, pure pursuit."}]},
 {id:"m2s-home", n:"06", title:"M2S Home Designer", area:"Embedded · IoT",
  blurb:"Design a smart home: place sensors, wire the boards, and run a day of automation in 3D.",
  origin:"DIY embedded projects, shown during tech-trainer internship", team:"Solo",
  uses:["Smart homes, buildings and farm water automation","Design-and-quote tool for installers","Embedded & IoT: AI writes code, engineers make it safe"],
  tags:["Sensors","Automation rules","3D home"],
  versions:[{v:"1.0",date:"Nov 2026",notes:"First public build: designer, device library, time-lapse simulation."}]},
 {id:"noise-equations", n:"07", title:"Propeller Noise Equations", area:"Aeroacoustics",
  blurb:"Every key propeller-noise equation, with live graphs you can bend by changing the blade.",
  origin:"Carleton aeroacoustics course", team:"Solo",
  uses:["Teaches and checks propeller-noise predictions","Aeroacoustics made simple, course content","Research path: drone and eVTOL noise"],
  tags:["Gutin","BPM","A-weighting"],
  versions:[{v:"1.0",date:"Nov 2026",notes:"First public build: equations, graphs, citations to public NASA/NACA reports."}]},
 {id:"rotor-noise", n:"08", title:"Rotor Noise Lab", area:"Aeroacoustics · Drones",
  blurb:"Drone, helicopter, twin-prop or VTOL: change every factor, fly it over a town and hear the noise.",
  origin:"Carleton aeroacoustics course", team:"Solo",
  uses:["Checks drone and air-taxi noise before city flights","Noise-footprint pre-checks for operators","Aeroacoustics and eVTOL roles"],
  tags:["Gutin check","Footprint","Flyover","Web Audio"],
  versions:[{v:"1.0",date:"Nov 2026",notes:"First public build: 5 vehicles, footprint map, flyover, Gutin vs independent check, real-world unsteady load."}]}
];

/* Production labs: real products in use, not simulations */
const LIVE = [
 {id:"worksmarto", n:"09", kind:"live", title:"worksmarto.com", area:"Live product · AI web platform",
  blurb:"An AI workflow blog and micro SaaS hub, run like a real business: compliance, ads, SEO and a freelance team.",
  url:"https://worksmarto.com", cta:"Visit worksmarto.com", status:"Live",
  proves:["Front end: WordPress theme work, custom pages, guided UI","Back end: Node.js / Express APIs, Supabase, WordPress snippets","AI APIs: Groq LLM, AI chatbot on site content, AI voice agent","Deploy: Hostinger, Vercel, GitHub, uptime monitoring"],
  compliance:["Cookie consent: trackers wait for consent","Privacy policy under India's DPDP Act and GDPR","Google AdSense approved and monetised","Search Console, sitemap and structured SEO"],
  marketing:["Meta ads to real visitors and newsletter subscribers","Split tests: cold vs warm audiences","SEO content engine with a set post format"],
  hiring:["Freelance tech experts and blog writers, credited by name","Hiring for upcoming micro SaaS builds"],
  next:["New micro SaaS tools built with AI","Udemy course: build micro SaaS with AI + digital marketing"]},
 {id:"t-wala", n:"10", kind:"live", title:"T Wala English", area:"Live product · Android app",
  blurb:"A story-based English learning app on Google Play: real scenes, rich vocabulary, applause when you use it right.",
  url:"https://play.google.com/store/apps/details?id=com.chaiwala.english", cta:"Open on Google Play", status:"Live",
  proves:["Mobile app: Expo, EAS Build, release branches","Content engine: story scenes, IELTS-level words, idioms","Monetisation: AdMob","Ship cycle: v1.1.0 in production on Google Play"],
  compliance:["Google Play policy compliance and review","Privacy policy and data-safety form","Advertising ID declared","No account data collected yet: progress stays on the device"],
  marketing:["Google app-install campaigns with tuned cost per install","Meta app-install test ads"],
  hiring:["Hiring junior and senior developers on Truelancer","Milestone-based remote builds"],
  next:["AI role-play for Business English","White-label version for English institutes"]},
 {id:"gethut", n:"11", kind:"live", title:"Gethut Shirt Collections", area:"E-commerce · White label",
  blurb:"A print-on-demand clothing store for campus and office, and a store engine offered as a white-label service.",
  url:"https://gethutshirtcollections.shop", cta:"Visit the store", status:"Relaunching", hidden:true,
  proves:["WooCommerce store build and design system","Print-on-demand partner integration","Cashfree + UPI payments","Order flow automation"],
  compliance:["Store policies: shipping, returns, privacy","Secure payment gateway"],
  marketing:["Meta ads tested","Brand: from campus to cabin"],
  hiring:["Designers and developers hired per project"],
  next:["White-label store setup for creators and small brands","Relaunch with a focused product line"]}
];
const LIVE_SHOWN = LIVE.filter(l=>!l.hidden);
const ALL = LABS.concat(LIVE_SHOWN);

const PAGES = [["index.html","Labs"],["journey.html","Journey"],["ventures.html#research","Research"],["ventures.html","Ventures"],["blog.html","Blog"],["resume.html","Resume"],["contact.html","Contact"]];
const LOGO = '<svg width="30" height="30" viewBox="0 0 32 32" aria-hidden="true"><circle cx="16" cy="16" r="14.5" fill="none" stroke="currentColor" stroke-width="1.6"/><ellipse cx="16" cy="16" rx="14.5" ry="5.5" fill="none" stroke="var(--acc)" stroke-width="1.6" transform="rotate(-28 16 16)"/><path d="M10 21V11l6 6 6-6v10" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linejoin="round" stroke-linecap="round"/></svg>';

/* Colour themes: remembered per browser when storage is allowed */
const THEMES = [["","Auto"],["paper","Blueprint"],["white","Clean white"],["space","Space dark"],["mars","Mars"]];
function readTheme(){ let t=null; try{ t=localStorage.getItem("mts-theme"); }catch(e){}
  if(!t){ const m=(window.name||"").match(/mts-theme=([a-z]+)/); if(m) t=m[1]; } return t; }
function saveTheme(t){ try{ t ? localStorage.setItem("mts-theme", t) : localStorage.removeItem("mts-theme"); }catch(e){}
  try{ window.name = (window.name||"").replace(/\s*mts-theme=[a-z]*/g,"") + (t ? " mts-theme="+t : ""); }catch(e){} }
function setTheme(t){ if (t) document.documentElement.setAttribute("data-theme", t); else document.documentElement.removeAttribute("data-theme");
  saveTheme(t); document.querySelectorAll(".themesel").forEach(x=>x.value=t||""); }
(function(){ const t=readTheme(); if (t) document.documentElement.setAttribute("data-theme", t); })();
function themeButton(){ const sel = document.createElement("select"); sel.className="themesel"; sel.setAttribute("aria-label","Colour theme");
  sel.innerHTML = THEMES.map(t=>'<option value="'+t[0]+'">🎨 '+t[1]+'</option>').join("");
  sel.value = document.documentElement.getAttribute("data-theme")||""; sel.onchange=()=>setTheme(sel.value); return sel; }

function layout(active){
  if (CFG.wp) { const b = themeButton(); b.classList.add("float"); document.body.append(b); return; } // WordPress theme draws header, menu, footer
  const h = document.createElement("header"); h.className = "top";
  h.innerHTML = '<div class="wrap"><a class="brand" href="index.html">'+LOGO+'MechToSpace</a><nav class="nav" aria-label="Main">'+
    PAGES.map(p=>'<a href="'+p[0]+'"'+(p[0]===active?' class="on" aria-current="page"':'')+'>'+p[1]+'</a>').join('')+'</nav></div>';
  h.querySelector('.wrap').append(themeButton());
  document.body.prepend(h);
  const f = document.createElement("footer");
  f.innerHTML = '<div class="wrap"><div><b style="color:var(--ink);font-family:var(--hd)">MechToSpace</b> · Relearn, rethink, rebuild engineering with AI.<br>A research venture of Software Innovation Labs, Erode, India.</div>'+
    '<div>Simulators are educational and assumption-based. Civil applications only.<br>Built with open tools: three.js, Web Audio, MediaPipe. <a href="contact.html">Research enquiries</a> · <a href="ventures.html">Ajith Ventures</a></div></div>';
  document.body.append(f);
}

function cardHTML(l){
  if (l.kind === "live") return '<article class="card live">'+
    '<div class="vid"><video muted loop playsinline preload="none" poster="'+CFG.clipBase+l.id+'.jpg" aria-label="Overview of '+l.title+'"><source src="'+CFG.clipBase+l.id+'.mp4" type="video/mp4"></video>'+
    '<span class="num">LAB '+l.n+'</span><span class="ver '+(l.status==="Live"?'ok':'')+'">● '+l.status+'</span><span class="play">↗ '+l.cta+'</span></div>'+
    '<div class="body"><div class="area">'+l.area+'</div><h3>'+l.title+'</h3><p>'+l.blurb+'</p>'+
    '<div class="foot"><span class="mut">Real production work</span><a href="lab.html#'+l.id+'">What it proves →</a></div></div>'+
    '<a class="cover" href="'+l.url+'" target="_blank" rel="noopener" aria-label="'+l.cta+'"></a></article>';
  const v = l.versions[0].v;
  return '<article class="card">'+
    '<div class="vid"><video muted loop playsinline preload="none" poster="'+CFG.clipBase+l.id+'.jpg" aria-label="Demo of '+l.title+'"><source src="'+CFG.clipBase+l.id+'.mp4" type="video/mp4"></video>'+
    '<span class="num">LAB '+l.n+'</span><span class="ver">v'+v+'</span><span class="play">▶ Try it live</span></div>'+
    '<div class="body"><div class="area">'+l.area+'</div><h3>'+l.title+'</h3><p>'+l.blurb+'</p>'+
    '<div class="foot"><span class="mut">'+l.team+'</span><a href="lab.html#'+l.id+'">Notes &amp; versions →</a></div></div>'+
    '<a class="cover" href="'+simURL(l)+'" target="_blank" rel="noopener" aria-label="Open the '+l.title+' simulator"></a></article>';
}

function autoplayCards(root){
  const vids = [...root.querySelectorAll("video")];
  if (!("IntersectionObserver" in window)) { vids.forEach(v=>v.play().catch(()=>{})); return; }
  const io = new IntersectionObserver(es=>es.forEach(e=>{
    const v = e.target;
    if (e.isIntersecting) { v.preload = "auto"; v.play().catch(()=>{}); } else v.pause();
  }), {threshold:.35});
  vids.forEach(v=>io.observe(v));
}

function renderCards(el, list){
  el.innerHTML = (list||LABS).map(cardHTML).join("");
  autoplayCards(el);
}
